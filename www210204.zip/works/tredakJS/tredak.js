function tredak() {
}